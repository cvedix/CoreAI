
#pragma once

#include <opencv2/freetype.hpp>
#include "../common/cvedix_node.h" 
/*
* ################################
* why need osd in our pipeline?
* ################################
* there are several reasons why we need osd,
* 1. we need debug, for the outputs of infer, tracker and ba, displaying is more straightforward than printing.
* 2. in some situations like cast screen, it is a functional requirement that we need display what we have done on screen to show what we can do to others who do not know about our product.
* 
* drawing the targets on current frame is the most common operation for osd.
*/
namespace cvedix_nodes {
    // config for cvedix_osd_node, define how to draw
    typedef struct cvedix_osd_node_option
    {
        int aaa = 0;
    } cvedix_osd_option;
    

    // on screen display(short as osd) node.
    // mainly used to display cvedix_frame_target on frame.
    class cvedix_osd_node: public cvedix_node {
    private:
        // support chinese font
        cv::Ptr<cv::freetype::FreeType2> ft2;
    protected:
        virtual std::shared_ptr<cvedix_objects::cvedix_meta> handle_frame_meta(std::shared_ptr<cvedix_objects::cvedix_frame_meta> meta) override;
        virtual std::shared_ptr<cvedix_objects::cvedix_meta> handle_control_meta(std::shared_ptr<cvedix_objects::cvedix_control_meta> meta) override;
    public:
        cvedix_osd_node(std::string node_name, std::string font = "");
        ~cvedix_osd_node();
    };

}