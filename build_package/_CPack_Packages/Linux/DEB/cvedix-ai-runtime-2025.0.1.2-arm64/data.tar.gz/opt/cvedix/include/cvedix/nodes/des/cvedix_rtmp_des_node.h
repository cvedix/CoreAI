#pragma once

#include <opencv2/core/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/videoio.hpp>
#include "../common/cvedix_des_node.h"

namespace cvedix_nodes {
    // rtmp des node, push video stream via rtmp protocal.
    // example:
    // rtmp://192.168.77.105/live/10000
    class cvedix_rtmp_des_node: public cvedix_des_node
    {
    private:
        /* data */
        std::string gst_template = "appsrc ! videoconvert ! %s bitrate=%d ! h264parse ! flvmux ! rtmpsink location=%s";
        cv::VideoWriter rtmp_writer;
    protected:
        // re-implementation, return nullptr.
        virtual std::shared_ptr<cvedix_objects::cvedix_meta> handle_frame_meta(std::shared_ptr<cvedix_objects::cvedix_frame_meta> meta) override; 
        // re-implementation, return nullptr.
        virtual std::shared_ptr<cvedix_objects::cvedix_meta> handle_control_meta(std::shared_ptr<cvedix_objects::cvedix_control_meta> meta) override;
    public:
        cvedix_rtmp_des_node(std::string node_name, 
                        int channel_index, 
                        std::string rtmp_url, 
                        cvedix_objects::cvedix_size resolution_w_h = {}, 
                        int bitrate = 1024,
                        bool osd = true,
                        std::string gst_encoder_name = "x264enc");
        ~cvedix_rtmp_des_node();

        virtual std::string to_string() override;
        
        std::string rtmp_url;
        // resolution for rtmp stream
        cvedix_objects::cvedix_size resolution_w_h;
        int bitrate;

        // for osd frame 
        bool osd;
        // set x264enc as the default encoder, we can use hardware encoder instead.
        std::string gst_encoder_name = "x264enc";
    };
}