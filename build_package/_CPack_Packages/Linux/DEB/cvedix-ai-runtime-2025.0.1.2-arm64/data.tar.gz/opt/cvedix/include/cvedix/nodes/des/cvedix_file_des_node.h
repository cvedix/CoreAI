#pragma once

#include <iostream>
#include <memory>
#include <chrono>
// compile tips:
// remove experimental/ if gcc >= 8.0
#include <experimental/filesystem>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/videoio.hpp>

#include "../common/cvedix_des_node.h"
#include "cvedix/objects/cvedix_frame_meta.h"
#include "cvedix/objects/cvedix_control_meta.h"
#include "cvedix/utils/cvedix_utils.h"


namespace cvedix_nodes {
    // file des node, save stream to local file
    class cvedix_file_des_node: public cvedix_des_node {
    private:
        /* data */
        std::string gst_template = "appsrc ! videoconvert ! %s bitrate=%d ! mp4mux ! filesink location=%s";
        cv::VideoWriter file_writer;

        int frames_already_record = -1;
        int frames_need_record = 0;

        // create file name
        // example: save_dir/name_prefix_stamp.mp4
        std::string get_new_file_name();
    protected:
        // re-implementation, return nullptr.
        virtual std::shared_ptr<cvedix_objects::cvedix_meta> handle_frame_meta(std::shared_ptr<cvedix_objects::cvedix_frame_meta> meta) override; 
        // re-implementation, return nullptr.
        virtual std::shared_ptr<cvedix_objects::cvedix_meta> handle_control_meta(std::shared_ptr<cvedix_objects::cvedix_control_meta> meta) override;
    public:
        cvedix_file_des_node(std::string node_name, 
                        int channel_index, 
                        std::string save_dir,
                        std::string name_prefix = "",
                        int max_duration_for_single_file = 2,
                        cvedix_objects::cvedix_size resolution_w_h = {},
                        int bitrate = 1024,
                        bool osd = true,
                        std::string gst_encoder_name = "x264enc");
        ~cvedix_file_des_node();

        // save directory
        std::string save_dir;
        // prefix of file name
        std::string name_prefix;
        // max duration for single file (minutes)
        int max_duration_for_single_file;

        cvedix_objects::cvedix_size resolution_w_h;
        int bitrate;
        bool osd;
        // set x264enc as the default encoder, we can use hardware encoder instead.
        std::string gst_encoder_name = "x264enc";
    };

}